import { getStore } from '@netlify/blobs';
import { createHmac, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { readFileSync } from 'node:fs';
const menu=JSON.parse(readFileSync(new URL('../../menu.json',import.meta.url),'utf8'));
const itemMap=new Map(menu.map(x=>[x.id,x]));
const money=c=>'$'+(c/100).toFixed(2);
const allowedTypes=new Set(['pickup','dinein','delivery']);
const allowedPayments=new Set(['cash','external_card','other']);
const json=(data,status=200,headers={})=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers}});
const error=(message,status=400)=>json({error:message},status);
const sign=(text,secret)=>createHmac('sha256',secret).update(text).digest('base64url');
function verify(req,secret){
 const cookie=(req.headers.get('cookie')||'').split('; ').find(x=>x.startsWith('bbpos='));
 if(!cookie)return null;
 const [body,signature,...extra]=cookie.slice(6).split('.');
 if(!body||!signature||extra.length)return null;
 const expected=sign(body,secret);
 if(expected.length!==signature.length||!timingSafeEqual(Buffer.from(signature),Buffer.from(expected)))return null;
 try{const payload=JSON.parse(Buffer.from(body,'base64url').toString());
   return payload.exp>Date.now()&&typeof payload.cashier==='string'?payload:null;
 }catch{return null;}
}
function loginCookie(cashier,secret){
 const body=Buffer.from(JSON.stringify({cashier,exp:Date.now()+8*3600000,nonce:randomBytes(12).toString('hex')})).toString('base64url');
 return `bbpos=${body}.${sign(body,secret)}; Path=/; Max-Age=28800; HttpOnly; Secure; SameSite=Strict`;
}
const statusOrder=o=>({id:o.id,created_at:o.created_at,cashier:o.cashier,customer:o.customer,type:o.type,payment_method:o.payment_method,total_cents:o.total_cents,discord_status:o.discord_status});
const store=()=>getStore({name:'bennys-pos-orders',consistency:'strong'});
async function orderById(id){ if(!/^[0-9a-f]{8}-[0-9a-f-]{27,}$/.test(id))return null;return await store().get('orders/'+id,{type:'json'});}
async function saveOrder(order){await store().setJSON('orders/'+order.id,order);}
async function allOrders(){
  const {blobs}=await store().list({prefix:'orders/'});
  if(blobs.length>3000)throw new Error('Report limit reached; export to a database before continuing');
  const entries=await Promise.all(blobs.map(b=>store().get(b.key,{type:'json'})));
  return entries.filter(Boolean).sort((a,b)=>b.created_at.localeCompare(a.created_at));
}
async function logDiscord(order,webhook){
 if(!webhook){order.discord_status='not_configured';await saveOrder(order);return order.discord_status;}
 const lines=order.items.map(i=>`${i.qty}× ${i.name} — ${money(i.total_cents)}`);
 const payload={username:"Benny's & Buns | POS",allowed_mentions:{parse:[]},embeds:[{title:`Benny's & Buns — Receipt ${order.id.slice(0,8).toUpperCase()}`,
 color:16755538,fields:[{name:'Customer',value:order.customer,inline:true},{name:'Cashier',value:order.cashier,inline:true},
 {name:'Order type',value:order.type,inline:true},{name:'Payment',value:order.payment_method+' (staff confirmed)',inline:true},
 {name:'Items',value:lines.join('\n').slice(0,1024)||'No items'},{name:'Subtotal',value:money(order.subtotal_cents),inline:true},
 {name:'Tax',value:money(order.tax_cents),inline:true},{name:'Total',value:money(order.total_cents),inline:true}],
 timestamp:order.created_at,footer:{text:'Manual payment confirmation — not a payment processor'}}]};
 try{
   const res=await fetch(webhook,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout(6000)});
   order.discord_status=res.ok?'sent':'failed';if(!res.ok)console.error('Discord response',res.status);
 }catch(e){console.error('Discord error',e.message);order.discord_status='failed';}
 await saveOrder(order);return order.discord_status;
}
const rateLimit=new Map(); // Best-effort per instance; not durable across serverless instances.
export default async function handler(req){
 try{
 const secret=process.env.COOKIE_SECRET||'',pin=process.env.POS_ACCESS_PIN||'';
 if(secret.length<32||pin.length<8||pin.includes('REPLACE_'))return error('POS is not configured: set a strong PIN and COOKIE_SECRET in Netlify.',503);
 const rate=Number(process.env.TAX_RATE||0);
 if(!Number.isFinite(rate)||rate<0||rate>0.3)return error('Invalid TAX_RATE configuration',503);
 const url=new URL(req.url);let pathname=url.pathname;
 pathname=pathname.replace(/^\/.netlify\/functions\/api/,'').replace(/^\/api/,'')||'/';
 const method=req.method;
 if(!['GET','POST'].includes(method))return error('Method not allowed',405);
 if(method==='POST'){
   const origin=req.headers.get('origin');if(origin&&new URL(origin).host!==url.host)return error('Invalid origin',403);
   if(!req.headers.get('content-type')?.includes('application/json'))return error('Expected JSON',415);
 }
 if(pathname==='/session'&&method==='GET'){
   const s=verify(req,secret);return json({authenticated:!!s,cashier:s?.cashier||null});
 }
 if(pathname==='/login'&&method==='POST'){
   const ip=(req.headers.get('x-nf-client-connection-ip')||'unknown');
   const a=rateLimit.get(ip)||{count:0,until:0};
   if(a.until>Date.now())return error('Too many attempts; try again later.',429);
   const b=await req.json(),submitted=String(b?.pin||'');
   const valid=submitted.length===pin.length&&timingSafeEqual(Buffer.from(submitted),Buffer.from(pin));
   if(!valid){a.count++;if(a.count>=8){a.count=0;a.until=Date.now()+900000;}rateLimit.set(ip,a);return error('Incorrect staff PIN',401);}
   rateLimit.delete(ip);
   const cashier=String(b?.cashier||'Staff').trim().slice(0,48).replace(/[\r\n<>]/g,'')||'Staff';
   return json({ok:true,cashier},200,{'Set-Cookie':loginCookie(cashier,secret)});
 }
 const session=verify(req,secret);if(!session)return error('Please log in.',401);
 if(pathname==='/logout'&&method==='POST')return json({ok:true},200,{'Set-Cookie':'bbpos=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Strict'});
 if(pathname==='/menu'&&method==='GET')return json({menu,taxRate:rate});
 if(pathname==='/orders'&&method==='POST'){
   const b=await req.json();
   if(!Array.isArray(b.items)||b.items.length<1||b.items.length>40)return error('Invalid order items');
   if(!allowedTypes.has(b.type)||!allowedPayments.has(b.payment_method))return error('Invalid type or payment');
   const items=[],seen=new Set();let subtotal=0;
   for(const line of b.items){
     const m=itemMap.get(line.id),qty=line.qty;
     if(!m||!Number.isInteger(qty)||qty<1||qty>30||seen.has(m.id))return error('Invalid items');
     seen.add(m.id);const price=m.price_cents;
     if(!Number.isSafeInteger(price)||price<0)return error('Menu configuration error',503);
     const itemTotal=price*qty;subtotal+=itemTotal;
     if(subtotal>100000000)return error('Order too large');
     items.push({id:m.id,name:m.name,qty,price_cents:price,total_cents:itemTotal});
   }
   const customer=String(b.customer||'Walk-in').trim().slice(0,80).replace(/[\r\n<>]/g,'')||'Walk-in';
   const order={id:randomUUID(),created_at:new Date().toISOString(),cashier:session.cashier,customer,type:b.type,
       payment_method:b.payment_method,items,subtotal_cents:subtotal,tax_cents:Math.round(subtotal*rate),total_cents:subtotal+Math.round(subtotal*rate),discord_status:'pending'};
   await saveOrder(order);
   const hook=process.env.DISCORD_WEBHOOK_URL||'';
   if(hook){let u;try{u=new URL(hook);}catch{return json({receipt:order,warning:'Order saved but invalid Discord webhook.'},201);}
     if(u.protocol!=='https:'||!['discord.com','discordapp.com'].includes(u.hostname)||!u.pathname.startsWith('/api/webhooks/'))return json({receipt:order,warning:'Order saved but invalid Discord webhook.'},201);
   }
   await logDiscord(order,hook);
   return json({receipt:order,discord_status:order.discord_status,note:'Staff confirmed payment. No payment processed.'},201);
 }
 const idMatch=pathname.match(/^\/orders\/([a-f0-9-]{36})(?:\/(resend))?$/);
 if(idMatch){const order=await orderById(idMatch[1]);if(!order)return error('Receipt not found',404);
   if(!idMatch[2]&&method==='GET')return json({receipt:order});
   if(idMatch[2]&&method==='POST')return json({status:await logDiscord(order,process.env.DISCORD_WEBHOOK_URL||'')});
 }
 if((pathname==='/reports'||pathname==='/orders')&&method==='GET'){
   const orders=await allOrders();
   if(pathname==='/orders')return json({orders:orders.slice(0,100).map(statusOrder)});
   const today=new Date().toISOString().slice(0,10);
   const dayOrders=orders.filter(o=>o.created_at.startsWith(today));
   return json({today_utc:today,summary:{orders:dayOrders.length,revenue_cents:dayOrders.reduce((s,o)=>s+o.total_cents,0)},orders:orders.slice(0,100).map(statusOrder)});
 }
 return error('Not found',404);
 }catch(e){console.error('POS API error',e);return error('Internal POS error. Check Netlify function logs.',500);}
}
